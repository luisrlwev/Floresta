<?php
 
$errorMSG = "";
 
// EMAIL
if (empty($_POST["email"])) {
    $errorMSG .= "Email is required ";
} else {
    $email = $_POST["email"];
}
 
//Add your email here
$EmailTo = "luis.rlwev@gmail.com" . ", ";
$EmailTo .= "cuentas@parapenteagencia.com";
$Subject = "La Floresta Próximamente";
 
// prepare email body text
$Body = "";
$Body .= "E-mail: ";
$Body .= $email;
$Body .= "\n";
 
// send email
$success = mail($EmailTo, $Subject, $Body, "From:".$email);
 
// redirect to success page
if ($success && $errorMSG == ""){
   echo "success";
}else{
    if($errorMSG == ""){
        echo "Algo salió mal :(";
    } else {
        echo $errorMSG;
    }
}
 
?>